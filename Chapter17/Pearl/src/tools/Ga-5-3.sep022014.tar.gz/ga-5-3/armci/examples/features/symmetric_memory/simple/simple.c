#if HAVE_CONFIG_H
#   include "config.h"
#endif

/*$Id: simple.c,v 1.1.2.1 2007-06-20 17:42:20 vinod Exp $*/

int main(int argc, char **argv)
{
    return 0;
}
